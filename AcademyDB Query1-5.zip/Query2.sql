SELECT 
    Name AS [Group Name], 
    Rating AS [Group Rating] 
FROM Groups;