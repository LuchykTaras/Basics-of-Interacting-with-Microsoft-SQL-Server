SELECT 
    Surname,
    -- Відсоток ставки по відношенню до надбавки:
    (Salary / NULLIF(Premium, 0)) * 100 AS [Salary to Premium %],
    -- Відсоток ставки по відношенню до загальної зарплати (ставка + надбавка):
    (Salary / (Salary + Premium)) * 100 AS [Salary to Total %]
FROM Teachers;