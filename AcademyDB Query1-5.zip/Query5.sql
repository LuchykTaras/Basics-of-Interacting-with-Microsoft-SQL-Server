SELECT Surname 
FROM Teachers 
WHERE Salary > 1050;