SELECT 
    'The dean of faculty ' + Name + ' is Unknown/John Doe.' AS [Faculty Info]
FROM Faculties;