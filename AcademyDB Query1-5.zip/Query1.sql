SELECT 
    Name, 
    Financing, 
    Id 
FROM Departments;